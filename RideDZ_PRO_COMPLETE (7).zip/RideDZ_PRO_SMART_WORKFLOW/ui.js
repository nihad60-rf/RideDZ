(()=>{const d=document,B=d.body;let th=localStorage.getItem('ridedz-theme')||'auto';
const ap=()=>B.dataset.theme=th==='auto'?(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'):th;ap();
const sp=d.createElement('div');sp.id='splash';sp.innerHTML='<div class="logo">Ride<span>DZ</span></div><p>سعر عادل · اختر سائقك</p>';B.appendChild(sp);
setTimeout(()=>{sp.classList.add('gone');setTimeout(()=>sp.remove(),500)},900);
const h=d.querySelector('header');if(h){const t=d.createElement('button');t.id='themeBtn';t.textContent='🌓';t.onclick=()=>{th=B.dataset.theme==='dark'?'light':'dark';try{localStorage.setItem('ridedz-theme',th)}catch{}ap()};h.appendChild(t)}
const au=d.querySelector('#auth');if(au&&B.dataset.hero){const e=d.createElement('div');e.className='hero';e.innerHTML=B.dataset.hero;au.prepend(e)}
const cards=[...d.querySelectorAll('aside>.card')],app=d.querySelector('#app');if(!cards.length||!app)return;
const nav=d.createElement('nav');nav.id='bnav';let cur=0;
(B.dataset.nav||'').split(',').forEach((s,i)=>{let[ic,lb]=s.split('|'),b=d.createElement('button');b.innerHTML=`<i>${ic}</i><span>${lb}</span><u></u>`;b.onclick=()=>sel(i);nav.appendChild(b)});
B.appendChild(nav);
function sel(i){cur=i;cards.forEach((c,k)=>c.classList.toggle('off',k!==i));[...nav.children].forEach((b,k)=>{b.classList.toggle('on',k===i);if(k===i)b.querySelector('u').style.display='none'})}
sel(+(B.dataset.start||0));
const vis=()=>nav.classList.toggle('hide',app.classList.contains('hide'));vis();new MutationObserver(vis).observe(app,{attributes:true});
(B.dataset.dot||'').split(',').forEach(s=>{let[id,i,go]=s.split(':'),el=d.getElementById(id);if(!el)return;i=+i;let was=!el.textContent.trim()||!!el.querySelector('.empty');
 new MutationObserver(()=>{let empty=!el.textContent.trim()||!!el.querySelector('.empty');if(!empty&&cur!==i){if(was&&go)sel(i);else nav.children[i].querySelector('u').style.display='block'}was=empty}).observe(el,{childList:true,subtree:true})})})();

window.mkIcon=k=>{const m={pickup:['a','A'],destination:['b','B'],driver:['c','🚗']}[k];if(!m||typeof L==='undefined')return;return L.divIcon({className:'',html:`<div class="pin ${m[0]}"><b>${m[1]}</b></div>`,iconSize:[44,52],iconAnchor:[22,50],popupAnchor:[0,-46]})};
