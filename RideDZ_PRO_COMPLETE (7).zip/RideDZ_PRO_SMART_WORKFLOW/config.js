window.RideDZConfig={SUPABASE_URL:'https://zfgneproiyopyjsczvmh.supabase.co',SUPABASE_ANON_KEY:'sb_publishable_8nShfHkx-6ZNqGYTrHcPsw_nxMPvNB_'};
