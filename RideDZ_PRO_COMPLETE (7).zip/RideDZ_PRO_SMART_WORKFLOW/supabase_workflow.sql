-- RideDZ PRO WORKFLOW v3
-- Passenger offer -> nearest drivers -> driver accepts/declines -> passenger confirms/declines
-- Completed/cancelled rides become history; new ride can be requested afterward.

alter table public.rides
  add column if not exists completed_at timestamptz,
  add column if not exists started_at timestamptz,
  add column if not exists driver_accepted_at timestamptz,
  add column if not exists passenger_confirmed_at timestamptz;

create table if not exists public.ride_history (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null unique references public.rides(id) on delete cascade,
  passenger_id uuid not null references public.profiles(id),
  driver_id uuid references public.profiles(id),
  status text not null,
  pickup_address text,
  destination_address text,
  distance_km numeric,
  estimated_duration_minutes integer,
  passenger_price numeric,
  accepted_price numeric,
  cancellation_reason text,
  cancelled_by uuid references public.profiles(id),
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz default now(),
  archived_at timestamptz default now()
);

create index if not exists ride_history_passenger_idx on public.ride_history(passenger_id, archived_at desc);
create index if not exists ride_history_driver_idx on public.ride_history(driver_id, archived_at desc);

alter table public.ride_history enable row level security;
drop policy if exists "ride_history_participant_select" on public.ride_history;
create policy "ride_history_participant_select" on public.ride_history
for select to authenticated
using (passenger_id = auth.uid() or driver_id = auth.uid());

-- Public-safe participant profile RPC; avoids recursive profiles RLS.
drop function if exists public.ridedz_public_profile(uuid);
create or replace function public.ridedz_public_profile(p_id uuid)
returns table(full_name text, phone text)
language sql security definer set search_path=public
as $$
  select p.full_name, p.phone
  from public.profiles p
  where p.id = p_id
    and (
      p.id = auth.uid()
      or exists(select 1 from public.rides r where r.passenger_id=auth.uid() and r.driver_id=p.id)
      or exists(select 1 from public.rides r where r.driver_id=auth.uid() and r.passenger_id=p.id)
    );
$$;
grant execute on function public.ridedz_public_profile(uuid) to authenticated;

-- Driver accepts the passenger's proposed ride. Atomic: only one driver can claim it.
drop function if exists public.ridedz_driver_accept_ride(uuid,numeric);
create or replace function public.ridedz_driver_accept_ride(p_ride_id uuid, p_price numeric)
returns public.rides
language plpgsql security definer set search_path=public
as $$
declare v public.rides;
begin
  select * into v from public.rides where id=p_ride_id for update;
  if v.id is null then raise exception 'RIDE_NOT_FOUND'; end if;
  if v.status <> 'searching' then raise exception 'RIDE_NOT_AVAILABLE'; end if;
  if not exists(select 1 from public.driver_profiles dp where dp.id=auth.uid() and dp.online=true and dp.available=true) then raise exception 'DRIVER_OFFLINE'; end if;

  update public.rides
  set driver_id=auth.uid(),
      accepted_price=coalesce(p_price, passenger_price),
      status='driver_selected',
      driver_accepted_at=now(),
      accepted_at=now()
  where id=p_ride_id;

  insert into public.ride_offers(ride_id,driver_id,proposed_price,status)
  values(p_ride_id,auth.uid(),coalesce(p_price,v.passenger_price),'accepted')
  on conflict (ride_id,driver_id) do update set status='accepted', proposed_price=excluded.proposed_price;

  update public.ride_offers
  set status='rejected'
  where ride_id=p_ride_id and driver_id<>auth.uid() and status='pending';

  select * into v from public.rides where id=p_ride_id;
  return v;
end;
$$;
grant execute on function public.ridedz_driver_accept_ride(uuid,numeric) to authenticated;

-- Driver declines: the ride remains searching and this driver is excluded by a rejected offer.
drop function if exists public.ridedz_driver_decline_ride(uuid,text);
create or replace function public.ridedz_driver_decline_ride(p_ride_id uuid, p_reason text)
returns boolean
language plpgsql security definer set search_path=public
as $$
begin
  if not exists(select 1 from public.rides where id=p_ride_id and status='searching') then
    return false;
  end if;
  insert into public.ride_offers(ride_id,driver_id,proposed_price,status)
  select p_ride_id,auth.uid(),passenger_price,'rejected'
  from public.rides where id=p_ride_id
  on conflict (ride_id,driver_id) do update set status='rejected', proposed_price=excluded.proposed_price;
  return true;
end;
$$;
grant execute on function public.ridedz_driver_decline_ride(uuid,text) to authenticated;

-- Passenger confirms the driver after driver acceptance.
drop function if exists public.ridedz_passenger_confirm_driver(uuid);
create or replace function public.ridedz_passenger_confirm_driver(p_ride_id uuid)
returns public.rides
language plpgsql security definer set search_path=public
as $$
declare v public.rides;
begin
  select * into v from public.rides where id=p_ride_id for update;
  if v.passenger_id is distinct from auth.uid() then raise exception 'NOT_PASSENGER'; end if;
  if v.status<>'driver_selected' or v.driver_id is null then raise exception 'DRIVER_NOT_WAITING'; end if;
  update public.rides set status='driver_confirmed', passenger_confirmed_at=now() where id=p_ride_id;
  select * into v from public.rides where id=p_ride_id;
  return v;
end;
$$;
grant execute on function public.ridedz_passenger_confirm_driver(uuid) to authenticated;

-- Passenger declines selected driver: reopen search, reject that driver and start again.
drop function if exists public.ridedz_passenger_decline_driver(uuid,text);
create or replace function public.ridedz_passenger_decline_driver(p_ride_id uuid,p_reason text)
returns public.rides
language plpgsql security definer set search_path=public
as $$
declare v public.rides; old_driver uuid;
begin
  select * into v from public.rides where id=p_ride_id for update;
  if v.passenger_id is distinct from auth.uid() then raise exception 'NOT_PASSENGER'; end if;
  if v.status<>'driver_selected' then raise exception 'NO_SELECTED_DRIVER'; end if;
  old_driver:=v.driver_id;
  if old_driver is not null then
    update public.ride_offers set status='rejected' where ride_id=p_ride_id and driver_id=old_driver;
  end if;
  update public.rides
  set driver_id=null, accepted_price=null, accepted_at=null, driver_accepted_at=null,
      passenger_confirmed_at=null, status='searching'
  where id=p_ride_id;
  select * into v from public.rides where id=p_ride_id;
  return v;
end;
$$;
grant execute on function public.ridedz_passenger_decline_driver(uuid,text) to authenticated;

-- Finish: archive immutable history and free the driver for new jobs.
drop function if exists public.ridedz_complete_ride(uuid);
create or replace function public.ridedz_complete_ride(p_ride_id uuid)
returns public.rides
language plpgsql security definer set search_path=public
as $$
declare v public.rides;
begin
  select * into v from public.rides where id=p_ride_id for update;
  if v.driver_id is distinct from auth.uid() then raise exception 'NOT_DRIVER'; end if;
  if v.status<>'in_progress' then raise exception 'RIDE_NOT_IN_PROGRESS'; end if;
  update public.rides set status='completed', completed_at=now() where id=p_ride_id;
  insert into public.ride_history(ride_id,passenger_id,driver_id,status,pickup_address,destination_address,distance_km,estimated_duration_minutes,passenger_price,accepted_price,started_at,completed_at)
  select id,passenger_id,driver_id,'completed',pickup_address,destination_address,distance_km,estimated_duration_minutes,passenger_price,accepted_price,started_at,now()
  from public.rides where id=p_ride_id
  on conflict (ride_id) do nothing;
  update public.driver_profiles set available=true, online=true where id=auth.uid();
  select * into v from public.rides where id=p_ride_id;
  return v;
end;
$$;
grant execute on function public.ridedz_complete_ride(uuid) to authenticated;

-- Cancel a ride and archive it. Driver becomes available again.
drop function if exists public.ridedz_cancel_ride(uuid,text);
create or replace function public.ridedz_cancel_ride(p_ride_id uuid,p_reason text)
returns public.rides
language plpgsql security definer set search_path=public
as $$
declare v public.rides;
begin
  select * into v from public.rides where id=p_ride_id for update;
  if v.id is null then raise exception 'RIDE_NOT_FOUND'; end if;
  if v.passenger_id is distinct from auth.uid() and v.driver_id is distinct from auth.uid() then raise exception 'NOT_PARTICIPANT'; end if;
  if v.status in ('completed','cancelled') then raise exception 'RIDE_CLOSED'; end if;
  update public.rides set status='cancelled',cancelled_by=auth.uid(),cancellation_reason=p_reason,cancelled_at=now() where id=p_ride_id;
    if v.driver_id is not null then update public.driver_profiles set available=true where id=v.driver_id; end if;
  select * into v from public.rides where id=p_ride_id;
  return v;
end;
$$;
grant execute on function public.ridedz_cancel_ride(uuid,text) to authenticated;

-- Start/arrive transitions with participant ownership.
drop function if exists public.ridedz_set_ride_status(uuid,text);
create or replace function public.ridedz_set_ride_status(p_ride_id uuid,p_status text)
returns public.rides
language plpgsql security definer set search_path=public
as $$
declare v public.rides;
begin
  select * into v from public.rides where id=p_ride_id for update;
  if v.driver_id is distinct from auth.uid() then raise exception 'NOT_DRIVER'; end if;
  if p_status='driver_arriving' and v.status='driver_confirmed' then update public.rides set status=p_status where id=p_ride_id;
  elsif p_status='driver_arrived' and v.status='driver_arriving' then update public.rides set status=p_status where id=p_ride_id;
  elsif p_status='in_progress' and v.status='driver_arrived' then update public.rides set status=p_status,started_at=now() where id=p_ride_id;
  else raise exception 'INVALID_TRANSITION'; end if;
  select * into v from public.rides where id=p_ride_id; return v;
end;
$$;
grant execute on function public.ridedz_set_ride_status(uuid,text) to authenticated;

-- Smart dispatch: only the nearest eligible drivers receive the request first.
drop function if exists public.ridedz_nearby_searching_rides(double precision,double precision);
create or replace function public.ridedz_nearby_searching_rides(p_lat double precision,p_lng double precision)
returns table(id uuid,passenger_id uuid,pickup_address text,destination_address text,pickup_latitude double precision,pickup_longitude double precision,destination_latitude double precision,destination_longitude double precision,distance_km numeric,estimated_duration_minutes integer,passenger_price numeric,status text,created_at timestamptz,driver_distance_km numeric,search_radius_km numeric)
language sql security definer set search_path=public
as $$
with rides0 as (
 select r.*,
   case when extract(epoch from(now()-r.created_at))<10 then 3 when extract(epoch from(now()-r.created_at))<20 then 5 when extract(epoch from(now()-r.created_at))<35 then 8 when extract(epoch from(now()-r.created_at))<55 then 12 else 20 end::numeric as radius,
   case when extract(epoch from(now()-r.created_at))<10 then 3 when extract(epoch from(now()-r.created_at))<20 then 5 when extract(epoch from(now()-r.created_at))<35 then 8 when extract(epoch from(now()-r.created_at))<55 then 12 else 20 end::int as batch
 from public.rides r where r.status='searching'
),
eligible as (
 select r.id,r.radius,r.batch,dl.driver_id,
  6371*2*asin(sqrt(power(sin(radians(r.pickup_latitude-dl.latitude)/2),2)+cos(radians(r.pickup_latitude))*cos(radians(dl.latitude))*power(sin(radians(r.pickup_longitude-dl.longitude)/2),2))) as dd
 from rides0 r join public.driver_locations dl on true
 join public.driver_profiles dp on dp.id=dl.driver_id and dp.online=true and dp.available=true
 where not exists(select 1 from public.ride_offers ro where ro.ride_id=r.id and ro.driver_id=dl.driver_id and ro.status in('rejected','accepted'))
), ranked as (
 select e.*,row_number() over(partition by e.id order by e.dd asc) as rn
 from eligible e
)
select r.id,r.passenger_id,r.pickup_address,r.destination_address,r.pickup_latitude,r.pickup_longitude,r.destination_latitude,r.destination_longitude,r.distance_km,r.estimated_duration_minutes,r.passenger_price,r.status,r.created_at,
 round(x.dd::numeric,2) as driver_distance_km,r.radius as search_radius_km
from rides0 r
join ranked x on x.id=r.id and x.driver_id=auth.uid() and x.rn<=r.batch and x.dd<=r.radius
order by r.created_at desc,x.dd asc;
$$;
grant execute on function public.ridedz_nearby_searching_rides(double precision,double precision) to authenticated;

-- Realtime
DO $$ BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.rides; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.ride_offers; EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.driver_locations; EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;
