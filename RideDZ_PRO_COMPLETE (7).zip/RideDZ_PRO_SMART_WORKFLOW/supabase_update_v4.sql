-- RideDZ PRO v4 — (à lancer APRÈS supabase_workflow.sql)
-- 1) Le tarif annulé n'est plus archivé : l'historique ne garde que les courses terminées.
-- 2) Les nouvelles demandes apparaissent en premier chez le chauffeur.

delete from public.ride_history where status <> 'completed';

create or replace function public.ridedz_cancel_ride(p_ride_id uuid,p_reason text)
returns public.rides language plpgsql security definer set search_path=public as $$
declare v public.rides;
begin
  select * into v from public.rides where id=p_ride_id for update;
  if v.id is null then raise exception 'RIDE_NOT_FOUND'; end if;
  if v.passenger_id is distinct from auth.uid() and v.driver_id is distinct from auth.uid() then raise exception 'NOT_PARTICIPANT'; end if;
  if v.status in ('completed','cancelled') then raise exception 'RIDE_CLOSED'; end if;
  update public.rides set status='cancelled',cancelled_by=auth.uid(),cancellation_reason=p_reason,cancelled_at=now() where id=p_ride_id;
  if v.driver_id is not null then update public.driver_profiles set available=true where id=v.driver_id; end if;
  select * into v from public.rides where id=p_ride_id;
  return v;
end $$;
grant execute on function public.ridedz_cancel_ride(uuid,text) to authenticated;
