-- RideDZ PRO — schéma de base (à lancer UNE fois, AVANT supabase_workflow.sql)
-- Sûr à relancer : tout est "if not exists" / "or replace".

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, phone text,
  role text not null default 'passenger' check (role in ('passenger','driver')),
  created_at timestamptz default now()
);

create table if not exists public.driver_profiles (
  id uuid primary key references public.profiles(id) on delete cascade,
  online boolean not null default false,
  available boolean not null default false,
  vehicle_model text, plate text, seats int default 4,
  updated_at timestamptz default now()
);

create table if not exists public.driver_locations (
  driver_id uuid primary key references public.profiles(id) on delete cascade,
  latitude double precision not null, longitude double precision not null,
  heading double precision, speed double precision, accuracy double precision,
  updated_at timestamptz default now()
);

create table if not exists public.rides (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id),
  driver_id uuid references public.profiles(id),
  status text not null default 'searching' check (status in
    ('searching','driver_selected','driver_confirmed','driver_arriving','driver_arrived','in_progress','completed','cancelled')),
  pickup_address text, destination_address text,
  pickup_latitude double precision, pickup_longitude double precision,
  destination_latitude double precision, destination_longitude double precision,
  distance_km numeric, estimated_duration_minutes integer,
  passenger_price numeric, accepted_price numeric,
  cancelled_by uuid references public.profiles(id), cancellation_reason text,
  cancelled_at timestamptz, accepted_at timestamptz,
  created_at timestamptz default now()
);
-- Une seule course active par passager (verrou côté base)
create unique index if not exists one_active_ride_per_passenger on public.rides(passenger_id)
  where status in ('searching','driver_selected','driver_confirmed','driver_arriving','driver_arrived','in_progress');
create index if not exists rides_driver_idx on public.rides(driver_id);

create table if not exists public.ride_offers (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null references public.rides(id) on delete cascade,
  driver_id uuid not null references public.profiles(id),
  proposed_price numeric,
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz default now(),
  unique (ride_id, driver_id)
);

-- Création automatique du profil à l'inscription
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,full_name,phone,role)
  values(new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone',
         case when new.raw_user_meta_data->>'role'='driver' then 'driver' else 'passenger' end)
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- RLS (aucune policy ne lit "profiles" depuis "profiles" => pas de récursion)
alter table public.profiles enable row level security;
alter table public.driver_profiles enable row level security;
alter table public.driver_locations enable row level security;
alter table public.rides enable row level security;
alter table public.ride_offers enable row level security;

drop policy if exists profiles_own on public.profiles;
create policy profiles_own on public.profiles for select to authenticated using (id=auth.uid());
drop policy if exists profiles_own_upd on public.profiles;
create policy profiles_own_upd on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid() and role=(select role from public.profiles where id=auth.uid()));

drop policy if exists dp_own on public.driver_profiles;
create policy dp_own on public.driver_profiles for all to authenticated using (id=auth.uid()) with check (id=auth.uid());

drop policy if exists dl_own_write on public.driver_locations;
create policy dl_own_write on public.driver_locations for all to authenticated using (driver_id=auth.uid()) with check (driver_id=auth.uid());
drop policy if exists dl_passenger_read on public.driver_locations;
create policy dl_passenger_read on public.driver_locations for select to authenticated
  using (exists(select 1 from public.rides r where r.driver_id=driver_locations.driver_id and r.passenger_id=auth.uid()
         and r.status in ('driver_selected','driver_confirmed','driver_arriving','driver_arrived','in_progress')));

drop policy if exists rides_passenger_select on public.rides;
create policy rides_passenger_select on public.rides for select to authenticated using (passenger_id=auth.uid() or driver_id=auth.uid());
drop policy if exists rides_passenger_insert on public.rides;
create policy rides_passenger_insert on public.rides for insert to authenticated
  with check (passenger_id=auth.uid() and status='searching' and driver_id is null);
-- Pas de policy UPDATE/DELETE : toutes les transitions passent par les fonctions RPC.

drop policy if exists offers_driver_select on public.ride_offers;
create policy offers_driver_select on public.ride_offers for select to authenticated using (driver_id=auth.uid());
