RideDZ PRO — النسخة الكاملة

الترتيب (مرة واحدة فقط) في Supabase الحالي > SQL Editor:
1) شغّل supabase_schema.sql   (الجداول + RLS + إنشاء الملف الشخصي تلقائيًا)
2) شغّل supabase_workflow.sql (الدوال: قبول/رفض، Dispatch، التاريخ، Realtime)
3) شغّل supabase_update_v4.sql (التاريخ للرحلات المكتملة فقط + الطلبات الجديدة أولًا)
4) Authentication > Providers > Email: يُفضّل إيقاف "Confirm email" أثناء التجربة.

النشر على Netlify: ارفع المجلد كاملًا (Add new site > Deploy manually) أو اسحبه إلى Netlify Drop.
الزبون: /passenger/    السائق: /driver/

ملاحظة: إذا كانت لديك جداول قديمة بنفس الأسماء، تأكد أن الأعمدة تطابق supabase_schema.sql قبل التشغيل.
